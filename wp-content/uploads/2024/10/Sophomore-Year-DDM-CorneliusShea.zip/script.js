const textElement = document.getElementById('text');
const optionButtonsElement = document.getElementById('option-buttons');

function startGame(){
  state = {};

  showTextNode(1);
  
}

function showTextNode(textNodeIndex){
  const textNode = textNodes.find(textNode => textNode.id === textNodeIndex);
  textElement.innerText = textNode.text;

  while(optionButtonsElement.firstChild) {
    optionButtonsElement.removeChild(optionButtonsElement.firstChild);
  }

  textNode.options.forEach(option => {
    if(showOption(option)) {
      const button = document.createElement('button');
      button.innerText = option.text;
      button.classList.add('btn');
      button.addEventListener('click', () => selectOption(option));
      optionButtonsElement.appendChild(button);

      
    }
  })
}

function showOption(option){
  return option.requiredState == null || option.requiredState(state);
}

function selectOption(option){
  const nextTextNodeId = option.nextText;
  if(nextTextNodeId <= 0){
    return startGame();
  }
  state = Object.assign(state, option.setState);
  showTextNode(nextTextNodeId);
  
}

const textNodes = [
  {
    id: 1, 
    text: 'You are running from something, it is chasing. What do you do?',
    options: [
      {
        text:'hide',
        nextText: 2,
      },
      {
        text:'run',
        nextText: 3,
      }
    ]
  },
  {
    id: 2,
    text:'You duck down behind the bushes and hold your breath. Did you think it wouldn’t find you? Wrong.',
    options: [
      {
        text:'restart',
        nextText:-1,
      },
      {
        text:'restart',
        nextText:-1,
      }
    ]
  },
  {
    id:3,
    text:'You run until you find an abandoned house, you run inside to find a plethora of rooms, and a closet.',
    options:[
      {
        text:'hide in closet',
        nextText:4,
      },
      {
        text:'find a room to hide in',
        nextText:9,
      }
    ]
  },
  {
    id:4,
    text:'It walks by, leaving you alone, you wait inside the closet for a while. When you hear it enter the second floor you exit the closet. But when you do the old house’s rotting floor collapses. You fall down into the basement and you hear the monster scurrying around trying to find a way down to you but there is no success. There are two tunnels down here, one goes left and one goes right.',
    options:[
      {
        text:'left',
        nextText:5,
      },
      {
        text:'right',
        nextText:6,
      }
    ]
  },
  {
    id:5,
    text:'You walk, for hours and hours. Eventually, you find yourself at a dead end, now you have to turn back. before you have the ability to turn around, in the pitch black you hear it, the sound of someone, or something, sprinting. It is much faster than any human could ever run. You accept your fate.',
    options:[
      {
        text:'restart',
        nextText:1,
      },
      {
        text:'restart',
        nextText:1,
      }
    ]
  },
  {
    id:6,
    text:'After walking for who knows how long, you see light. Then, you hear it behind you, its screams and howls. You run, as fast as you can, and when you finally make it out into the light, you look back into the tunnel. Inside it, you see it, staring, watching. You run until you find a road, and when you do you wait for someone to pull over. Finally someone does, you get in the car, and when you look up, it is not human, you are not safe.',
    options:[
      {
        text:'attack',
        nextText:7,
      },
      {
        text:'jump out of car',
        nextText:8,
      }
    ]
  },
  {
    id:7,
    text:'You’re funny. Did you really think you could fight this thing? Its inhuman, it is something beyond your comprehension. Good try, goodbye.',
    options:[
      {
        text:'restart',
        nextText:-1,
      },
      {
        text:'restart',
        nextText:-1,
      }
    ]
  },
  {
    id:8,
    text:'You jump out of the car, rolling in the dirt. The car comes to a screeching halt before your head slams right into a tree. You eventually wake up, and you see something on the ground. It is the monster, but it is no longer that. It is a lifeless pile of skin. You walk and walk until you find a pond, and when you do you look at your reflection. What is it? What do you see. You are it. You have become the very thing that you were running from. It has taken control, and now that you have realized, there is no helping you. ',
    options:[
      {
        text:'restart',
        nextText:-1,
      },
      {
        text:'restart',
        nextText:-1,
      }
    ]
  },
  {
    id:9,
    text:'You run into a room on the second floor, you shut and lock the door behind you, and you see the shadow of the figure that was chasing you pass by. The room is barren all but a single hanging bulb in the middle.',
    options:[
      {
        text:'climb out window',
        nextText:10,
      },
      {
        text:'leave room',
        nextText:11,
      }
    ]
  },
  {
    id:10,
    text:'You fall, break your leg, and the figure approaches you. You are done for.',
    options:[
      {
        text:'restart',
        nextText:-1,
      },
      {
        text:'restart',
        nextText:-1,
      }
    ]
  },
  {
    id:11,
    text:'You decide to go downstairs and walk out the back door, to hopefully find a way out of this forest. As you get farther from the house you hear IT howl, it sees you and is going to get you. You run and run and run until you finally see the sun start to ride, and as you exist the treeline and see a road you look back, and there it is. That uncanny look, staring back at you from the trees. You escaped... for now.',
    options:[
      {
        text:'restart',
        nextText:-1,
      },
      {
        text:'restart',
        nextText:-1,
      }
    ]
  }
]

startGame();